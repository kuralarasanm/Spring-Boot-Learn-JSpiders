package org.jsp.merchantbootapp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantBootApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(MerchantBootApp2Application.class, args);
	}
// THIS IS STEP ONE
}
