package org.jsp.merchantbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MerchantBootAppApplication.class, args);
	}

}
