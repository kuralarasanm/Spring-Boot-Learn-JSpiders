package org.jsp.merchantbootapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MerchantBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
